<?php get_header(); ?>
<main id="main">
<?php if(is_product_category() && single_term_title('',false)==='快速料理'): ?>
<img class="meals-banner" src="<?php echo esc_url(get_theme_file_uri('assets/reference-meals.webp')); ?>" alt="參考站的常溫商品活動橫幅">
<p class="sample-caption">版型預覽｜圖中優惠為參考活動，本機試購依購物車金額計算。</p>
<?php endif; ?>
<div class="store-content <?php if(!is_product()) echo 'listing'; ?>"><?php if(!is_product()): ?><aside><a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">全部商品</a><?php sumi_category_links(); ?></aside><?php endif; ?><div class="results"><?php woocommerce_content(); ?></div></div>
</main><?php get_footer(); ?>

