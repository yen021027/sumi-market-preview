const mast = document.querySelector('.mast');
if (mast) {
  const panels = [...mast.querySelectorAll('details')];
  for (const panel of panels) {
    panel.addEventListener('toggle', () => {
      if (!panel.open) return;
      for (const other of panels) if (other !== panel) other.open = false;
      if (panel.classList.contains('find')) panel.querySelector('input').focus();
    });
    if (panel.closest('.menu') && matchMedia('(hover:hover)').matches) {
      panel.addEventListener('pointerenter', () => panel.open = true);
      panel.addEventListener('pointerleave', () => panel.open = false);
    }
  }
  document.addEventListener('click', e => panels.forEach(panel => {
    if (!panel.contains(e.target)) panel.open = false;
  }));
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    for (const panel of panels) if (panel.open) {
      panel.open = false;
      panel.querySelector('summary').focus();
    }
  });
}
document.addEventListener('click', e => {
  const step = e.target.closest('[data-step]');
  if (!step) return;
  const qty = step.parentElement.querySelector('input.qty');
  if (!qty) return;
  if (step.dataset.step === '1') qty.stepUp(); else qty.stepDown();
  qty.dispatchEvent(new Event('change', {bubbles:true}));
});
document.querySelector('.page-size select')?.addEventListener('change', e=>e.target.form.requestSubmit());

if (window.jQuery && window.wc_add_to_cart_params) {
  const $body = jQuery(document.body);
  const bag = document.querySelector('.bag');
  const status = document.querySelector('#cart-status');
  $body.on('added_to_cart', () => {
    if (!bag) return;
    bag.classList.toggle('float-feedback', mast.getBoundingClientRect().bottom <= 0);
    bag.open = true;
    if (status) status.textContent = '已加入購物車。';
    const panel = bag.querySelector('.bag-panel');
    if (!matchMedia('(prefers-reduced-motion: reduce)').matches) {
      panel.animate([{opacity:0, transform:'translateY(-10px)'},{opacity:1, transform:'translateY(0)'}], {duration:220,easing:'ease-out'});
    }
  });
  bag?.addEventListener('toggle', () => {
    if (!bag.open) bag.classList.remove('float-feedback');
  });
  const form = document.querySelector('.product-type-simple .summary form.cart');
  form?.addEventListener('submit', async event => {
    const button = form.querySelector('button[name="add-to-cart"]');
    if (!button || !bag || !form.checkValidity()) return;
    event.preventDefault();
    if (button.disabled) return;
    const data = new FormData(form);
    data.set('product_id',button.value);
    button.disabled = true;
    button.classList.add('is-adding');
    button.setAttribute('aria-busy','true');
    let error = form.querySelector('.cart-feedback-error');
    if (error) error.remove();
    try {
      const endpoint = wc_add_to_cart_params.wc_ajax_url.replace('%%endpoint%%','add_to_cart');
      const response = await fetch(endpoint,{method:'POST',body:data,credentials:'same-origin'});
      if (!response.ok) throw new Error();
      const result = await response.json();
      if (result.error && result.product_url) { location.assign(result.product_url); return; }
      if (!result.fragments) throw new Error();
      $body.trigger('added_to_cart',[result.fragments,result.cart_hash,jQuery(button)]);
    } catch {
      error = document.createElement('p');
      error.className = 'cart-feedback-error';
      error.setAttribute('role','alert');
      error.textContent = '未能確認加入結果，請先查看購物車。';
      form.append(error);
    } finally {
      button.disabled = false;
      button.classList.remove('is-adding');
      button.removeAttribute('aria-busy');
    }
  });
}

