<!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head><body <?php body_class(); ?>><?php wp_body_open(); ?>
<a class="skip" href="#main">跳至主要內容</a><header class="mast">
<a class="identity" href="<?php echo esc_url(home_url('/')); ?>"><b aria-hidden="true">炭</b><strong><?php bloginfo('name'); ?></strong><small>SUMI MARKET</small></a>
<?php if(function_exists('WC')): $shop=wc_get_page_permalink('shop'); ?>
<div class="utilities"><details class="find"><summary aria-label="搜尋" title="搜尋"><?php sumi_icon('search'); ?></summary><form action="<?php echo esc_url(home_url('/')); ?>" method="get"><input type="search" name="s" aria-label="找商品" placeholder="找商品" required><input type="hidden" name="post_type" value="product"></form></details>
<a aria-label="會員中心" title="會員中心" href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>"><?php sumi_icon('account'); ?></a>
<details class="bag"><summary aria-label="購物車" title="購物車"><?php sumi_icon('bag'); echo sumi_bag_count(); ?></summary><div class="bag-panel"><div class="widget_shopping_cart_content"><?php woocommerce_mini_cart(); ?></div></div></details></div>
<nav class="menu" aria-label="商品導覽"><a href="<?php echo esc_url(home_url('/#teas')); ?>">本週選肉</a>
<?php $quick=get_term_by('name','快速料理','product_cat');if($quick): ?><a href="<?php echo esc_url(get_term_link($quick)); ?>">美味快速上桌</a><?php endif; ?>
<details><summary>【肉品分類】</summary><div><?php sumi_category_links(); ?></div></details>
<details><summary>【超市選物】</summary><div><a href="<?php echo esc_url($shop); ?>">全部商品</a><?php sumi_category_links(); ?></div></details>
<details><summary>【關於我們】</summary><div><a href="<?php echo esc_url(home_url('/#about-market')); ?>">商店介紹</a></div></details>
<details><summary>【購物說明】</summary><div><a href="<?php echo esc_url(home_url('/#shopping-guide')); ?>">配送與付款</a><a href="<?php echo esc_url(wc_get_account_endpoint_url('orders')); ?>">查詢訂單</a></div></details></nav>
<?php endif; ?></header><span class="screen-reader-text" id="cart-status" role="status"></span>

