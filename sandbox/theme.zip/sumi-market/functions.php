<?php
add_action('after_setup_theme', function () {
    add_theme_support('woocommerce');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('shanjian', get_stylesheet_uri(), [], '3.3');
});



function sumi_categories() {
    $terms = get_terms(['taxonomy'=>'product_cat','hide_empty'=>true]);
    return is_wp_error($terms) ? [] : $terms;
}
function sumi_category_links() {
    foreach (sumi_categories() as $term) {
        printf('<a href="%s">%s</a>', esc_url(get_term_link($term)), esc_html($term->name));
    }
}
function sumi_icon($name) {
    $paths = [
        'search'=>'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
        'account'=>'<circle cx="12" cy="7" r="4" fill="currentColor"/><path d="M3 21c0-8 18-8 18 0Z" fill="currentColor"/>',
        'bag'=>'<path d="M4 9h16l1 12H3Z" fill="currentColor"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    ];
    echo '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'.$paths[$name].'</svg>';
}
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('sumi-store',get_theme_file_uri('store.js'),function_exists('WC') ? ['wc-add-to-cart','wc-cart-fragments'] : [], '3.2.1',true);
    if(function_exists('WC')) wp_enqueue_script('wc-cart-fragments');
});
add_filter('woocommerce_product_tabs',function($tabs){
    $tabs['description']=['title'=>'商品描述','priority'=>10,'callback'=>function(){global $product;echo wp_kses_post(wpautop($product->get_description() ?: $product->get_short_description()));}];
    $tabs['delivery']=['title'=>'送貨及付款方式','priority'=>20,'callback'=>function(){echo '<h2>送貨及付款方式</h2><p>台灣宅配。運費依結帳頁顯示，會員可使用綠界信用卡測試付款。</p>';}];
    if(isset($tabs['reviews'])) $tabs['reviews']['title']='顧客評價';
    return $tabs;
});
add_action('woocommerce_before_quantity_input_field',function(){if(is_product()) echo '<button type="button" class="step" data-step="-1" aria-label="減少數量">−</button>';});
add_action('woocommerce_after_quantity_input_field',function(){if(is_product()) echo '<button type="button" class="step" data-step="1" aria-label="增加數量">＋</button>';});
function sumi_per_page() {
    $n=absint($_GET['per_page'] ?? 48);
    return in_array($n,[24,48,72],true) ? $n : 48;
}
add_filter('loop_shop_per_page','sumi_per_page',20);
add_action('woocommerce_before_shop_loop',function(){
    echo '<form class="page-size" method="get"><label><span class="screen-reader-text">每頁顯示數量</span><select name="per_page">';
    foreach([24,48,72] as $n) printf('<option value="%d" %s>每頁顯示 %d 個</option>',$n,selected($n,sumi_per_page(),false),$n);
    echo '</select></label>';wc_query_string_form_fields(null,['per_page','paged','product-page']);echo '<noscript><button>套用</button></noscript></form>';
},29);



function sumi_bag_count() {
    $count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
    return sprintf('<span class="bag-count" %s>%d</span>', $count ? '' : 'hidden', $count);
}
add_filter('woocommerce_add_to_cart_fragments',function($fragments){
    $fragments['span.bag-count'] = sumi_bag_count();
    return $fragments;
});

