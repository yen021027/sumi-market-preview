<?php get_header(); ?>
<main id="main">
 <a class="reference-banner" href="#teas" aria-label="查看推薦商品"><img src="<?php echo esc_url(get_theme_file_uri('assets/reference-home.webp')); ?>" width="1512" height="947" fetchpriority="high" alt="銘柄牛、醬料與禮盒主視覺"></a>
 <section class="catalog" id="teas"><div class="section-heading"><h2>推 薦 商 品</h2><p lang="en">Recommended Items</p></div>
 <?php if(function_exists('WC')) echo do_shortcode('[products limit="12" columns="3" orderby="date" order="ASC" paginate="true"]'); ?>
 </section>
<section class="catalog info-row" id="about-market"><div class="section-heading"><h2>關 於 我 們</h2><p>About Us</p></div><div class="story"><img src="<?php echo esc_url(get_theme_file_uri('assets/cuts.jpg')); ?>" alt="肉品選集" loading="lazy"><div><h3><?php bloginfo('name'); ?></h3><p>從一片厚切牛排，到兩人共享的燒肉組合，在這裡挑選今晚的主菜。</p><a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">瀏覽全部商品</a></div></div></section>
<section class="catalog info-row" id="shopping-guide"><div class="section-heading"><h2>購 物 說 明</h2><p>Shopping Guide</p></div><details><summary>商品如何配送？</summary><p>提供台灣宅配，配送費用顯示於購物車及結帳頁。</p></details><details><summary>如何付款及查詢訂單？</summary><p>登入後可選綠界信用卡測試付款。下單後請到會員中心查看訂單紀錄。</p></details></section></main><?php get_footer(); ?>

